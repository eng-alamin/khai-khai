{{-- resources/views/livewire/login.blade.php --}}
<div>
<style>
    :root {
        --pink: #e91e8c;
        --kk-purple-dark: #3d0a6e;
        --kk-purple: #7c1e8c;
        --kk-dark: #1A1A2E;
        --kk-border: #E8E8F0;
    }
    body {
        background: linear-gradient(135deg, #3d0a6e 0%, #7c1e8c 50%, var(--pink) 100%);
        min-height: 100vh;
        font-family: 'Segoe UI', sans-serif;
    }

    /* ── Card ── */
    .login-card {
        background: #fff;
        border-radius: 20px;
        box-shadow: 0 8px 40px rgba(26,26,46,.25);
        border: 1px solid var(--kk-border);
        overflow: hidden;
    }
    .login-header {
        background: linear-gradient(135deg, var(--kk-purple-dark) 0%, var(--kk-purple) 50%, var(--pink) 100%);
        padding: 2rem;
        text-align: center;
    }
    .login-header .brand-emoji { font-size: 2.5rem; }
    .login-header h1 { color: #fff; font-weight: 700; font-size: 1.4rem; margin: .4rem 0 .25rem; }
    .login-header p  { color: rgba(255,255,255,.85); font-size: .85rem; margin: 0; }
    .login-body { padding: 2rem; }

    /* ── Form controls ── */
    .form-label {
        font-size: .82rem; font-weight: 600;
        color: var(--kk-dark); margin-bottom: .35rem;
    }
    .form-control {
        border: 1.5px solid var(--kk-border);
        border-radius: 10px;
        padding: .65rem 1rem;
        font-size: .9rem;
        background: #FAFAFA;
        transition: border-color .2s, box-shadow .2s;
    }
    .form-control:focus {
        border-color: var(--pink);
        box-shadow: 0 0 0 3px rgba(233,30,140,.15);
        background: #fff;
        outline: none;
    }
    .form-control.is-invalid { border-color: #DC3545; background: #FFF5F5; }
    .input-group-text {
        background: #FCE9F4;
        border: 1.5px solid var(--kk-border);
        border-right: none;
        color: var(--pink);
        border-radius: 10px 0 0 10px;
        font-size: 1rem;
    }
    .input-group .form-control { border-radius: 0 10px 10px 0; }
    .invalid-feedback { font-size: .78rem; }

    /* ── Password toggle ── */
    .pw-wrap { position: relative; }
    .pw-toggle {
        position: absolute; right: 12px; top: 50%;
        transform: translateY(-50%);
        background: none; border: none;
        color: #ADB5BD; cursor: pointer; font-size: 1rem;
        padding: 0; line-height: 1;
    }
    .pw-toggle:hover { color: var(--pink); }

    /* ── Error alert ── */
    .error-alert {
        background: #FFF0F0; border: 1px solid #FFCDD2;
        border-radius: 10px; padding: .85rem 1rem;
        font-size: .85rem; color: #C62828;
        display: flex; gap: 8px; align-items: flex-start;
        margin-bottom: 1.2rem;
    }

    /* ── Primary button ── */
    .btn-kk {
        background: linear-gradient(135deg, var(--kk-purple-dark) 0%, var(--kk-purple) 50%, var(--pink) 100%);
        color: #fff; border: none; border-radius: 12px;
        padding: .8rem; font-weight: 700; font-size: 1rem;
        width: 100%; transition: all .2s;
        box-shadow: 0 4px 15px rgba(233,30,140,.3);
    }
    .btn-kk:hover:not(:disabled) {
        transform: translateY(-1px);
        box-shadow: 0 6px 20px rgba(233,30,140,.4);
        color: #fff;
    }
    .btn-kk:disabled { opacity: .65; transform: none; }

    /* ── Divider ── */
    .divider {
        display: flex; align-items: center; gap: 12px;
        margin: 1.2rem 0; color: #ADB5BD; font-size: .8rem;
    }
    .divider::before, .divider::after {
        content: ''; flex: 1; height: 1px;
        background: var(--kk-border);
    }

    /* ── Register link box ── */
    .register-box {
        background: #FCE9F4;
        border: 1px solid rgba(233,30,140,.2);
        border-radius: 12px; padding: 1rem;
        text-align: center; font-size: .85rem;
        color: var(--kk-dark);
    }
    .register-box a { color: var(--pink); font-weight: 700; text-decoration: none; }
    .register-box a:hover { text-decoration: underline; }
</style>

<div class="container py-5" style="max-width: 440px;">
    <div class="login-card">

        {{-- Header --}}
        <div class="login-header">
            <div class="brand-emoji">🍽️</div>
            <h1>Log in to KhaiKhai</h1>
            <p>Access your account</p>
        </div>

        {{-- Body --}}
        <div class="login-body">

            {{-- Error message --}}
            @if($errorMsg)
                <div class="error-alert">
                    <span>⚠️</span>
                    <span>{{ $errorMsg }}</span>
                </div>
            @endif

            {{-- Session error (e.g. from middleware) --}}
            @if(session('error'))
                <div class="error-alert">
                    <span>⚠️</span>
                    <span>{{ session('error') }}</span>
                </div>
            @endif

            <div class="row g-3">

                {{-- Email --}}
                <div class="col-12">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text">✉️</span>
                        <input type="email"
                            class="form-control @error('email') is-invalid @enderror"
                            wire:model.live.debounce.400ms="email"
                            placeholder="example@email.com"
                            autofocus>
                    </div>
                    @error('email')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Password --}}
                <div class="col-12">
                    <div class="d-flex justify-content-between">
                        <label class="form-label">Password</label>
                        <a href="{{ route('password.request') }}"
                            style="font-size:.78rem; color:var(--pink); text-decoration:none;">
                            Forgot password?
                        </a>
                    </div>
                    <div class="pw-wrap">
                        <div class="input-group">
                            <span class="input-group-text">🔒</span>
                            <input type="password"
                                id="pwField"
                                class="form-control @error('password') is-invalid @enderror"
                                wire:model.live="password"
                                placeholder="Your password">
                        </div>
                        <button type="button" class="pw-toggle" onclick="togglePw()" id="pwToggleBtn" aria-label="Show password">
                            👁️
                        </button>
                    </div>
                    @error('password')
                        <div class="invalid-feedback d-block">{{ $message }}</div>
                    @enderror
                </div>

                {{-- Remember me --}}
                <div class="col-12">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox"
                            wire:model="remember" id="rememberMe"
                            style="accent-color: var(--pink);">
                        <label class="form-check-label" for="rememberMe"
                            style="font-size:.85rem; color:#6C757D; cursor:pointer;">
                            Remember me
                        </label>
                    </div>
                </div>

                {{-- Submit --}}
                <div class="col-12 mt-2">
                    <button type="button" class="btn-kk"
                        wire:click="login"
                        wire:loading.attr="disabled"
                        wire:target="login">
                        <span wire:loading.remove wire:target="login">
                            🚀 Log In
                        </span>
                        <span wire:loading wire:target="login">
                            <span class="spinner-border spinner-border-sm me-2"></span>
                            Verifying...
                        </span>
                    </button>
                </div>

            </div>{{-- row --}}

            <div class="divider">OR</div>

            {{-- Register link --}}
            <div class="register-box">
                <a href="{{ route('customer.register') }}">Register here</a>
                <br><br>
                Restaurant Owner?
                <a href="{{ route('vendor.register') }}">Register here</a>
                <br>
                <span style="font-size:.78rem; color:#ADB5BD; margin-top:4px; display:block;">
                    Want to be a Rider?
                    <a href="{{ route('rider.register') }}">Rider App</a>
                </span>
            </div>

        </div>{{-- login-body --}}
    </div>{{-- login-card --}}

    <p class="text-center mt-3" style="font-size:.75rem; color:#f0e0f0;">
        © {{ date('Y') }} KhaiKhai · All Rights Reserved
    </p>
</div>

<script>
function togglePw() {
    const f = document.getElementById('pwField');
    const b = document.getElementById('pwToggleBtn');
    if (f.type === 'password') {
        f.type = 'text';
        b.textContent = '🙈';
    } else {
        f.type = 'password';
        b.textContent = '👁️';
    }
}
</script>
</div>