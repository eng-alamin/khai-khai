<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('categories', function (Blueprint $table) {
            $table->id();
 
            // Category information
            $table->string('name', 80);
            $table->string('slug', 90)->unique();
 
            // Tile image (e.g. Offers, Fruits, Vegetables, Nestlé)
            $table->string('image_url', 255)->nullable();
 
            // Ordering
            $table->unsignedSmallInteger('sort_order')->default(0);
 
            // Status
            $table->boolean('is_active')->default(true);
 
            $table->timestamps();
 
            $table->index(['is_active', 'sort_order']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('categories');
    }
};
