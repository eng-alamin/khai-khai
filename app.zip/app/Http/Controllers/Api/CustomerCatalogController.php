<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\FoodResource;
use App\Http\Resources\ProductResource;
use App\Http\Resources\RestaurantResource;
use App\Http\Resources\SliderResource;
use App\Models\Category;
use App\Models\Food;
use App\Models\Product;
use App\Models\Restaurant;
use App\Models\Slider;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\AnonymousResourceCollection;

/**
 * Read-only catalog for the customer app. The queries mirror the Livewire
 * components (HomeComponent, RestaurantComponent, ItemComponent) so the app
 * and the website always show the same restaurants and food.
 */
class CustomerCatalogController extends Controller
{
    private const RESTAURANT_COLUMNS = [
        'id', 'name', 'slug', 'category', 'emoji',
        'logo_url', 'banner_url', 'city', 'avg_rating', 'total_reviews',
        'tag', 'is_open',
    ];

    /** GET /customer/home */
    public function home(): JsonResponse
    {
        $restaurants = $this->visibleRestaurants()
            ->orderByDesc('avg_rating')
            ->limit(6)
            ->get(self::RESTAURANT_COLUMNS);

        $menuItems = $this->visibleFoods()
            ->orderBy('sort_order')
            ->limit(8)
            ->get();

        $products = Product::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->limit(4)
            ->get([
                'id', 'category_id', 'name', 'slug', 'price',
                'compare_price', 'emoji', 'image_url', 'section', 'sort_order',
            ]);

        $categories = Category::query()
            ->where('type', Category::TYPE_FOOD)
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->get(['id', 'name', 'emoji']);

        $sliders = Slider::query()
            ->where('is_active', true)
            ->orderByDesc('id')
            ->get(['id', 'image', 'url']);

        return response()->json([
            'data' => [
                'restaurants' => RestaurantResource::collection($restaurants)->resolve(),
                'menu_items'  => FoodResource::collection($menuItems)->resolve(),
                'products'    => ProductResource::collection($products)->resolve(),
                'categories'  => $categories->map(fn (Category $c) => [
                    'id'    => $c->id,
                    'name'  => $c->name,
                    'emoji' => $c->emoji,
                ])->all(),
                'sliders'     => SliderResource::collection($sliders)->resolve(),
            ],
        ]);
    }

    /** GET /customer/restaurants?search=&category=&page= */
    public function restaurants(Request $request): AnonymousResourceCollection
    {
        $validated = $request->validate([
            'search'   => ['nullable', 'string', 'max:100'],
            'category' => ['nullable', 'string', 'max:100'],
        ]);

        $search   = trim((string) ($validated['search'] ?? ''));
        $category = $validated['category'] ?? null;

        $restaurants = $this->visibleRestaurants()
            ->when($search !== '', fn (Builder $q) => $q->where(
                fn (Builder $q2) => $q2->where('name', 'like', "%{$search}%")
                    ->orWhere('category', 'like', "%{$search}%")
            ))
            ->when($category !== null && $category !== '', fn (Builder $q) => $q->where('category', $category))
            ->orderByDesc('avg_rating')
            ->paginate(20, self::RESTAURANT_COLUMNS);

        return RestaurantResource::collection($restaurants);
    }

    /** GET /customer/restaurant-categories */
    public function restaurantCategories(): JsonResponse
    {
        $categories = $this->visibleRestaurants()
            ->whereNotNull('category')
            ->distinct()
            ->orderBy('category')
            ->pluck('category');

        return response()->json(['data' => $categories->values()->all()]);
    }

    /** GET /customer/menu-categories */
    public function menuCategories(): JsonResponse
    {
        // Distinct name + emoji only (same as ItemComponent), so no id here.
        $categories = Category::query()
            ->where('type', Category::TYPE_FOOD)
            ->where('is_active', true)
            ->select('name', 'emoji')
            ->distinct()
            ->orderBy('name')
            ->get();

        return response()->json([
            'data' => $categories->map(fn (Category $c) => [
                'name'  => $c->name,
                'emoji' => $c->emoji,
            ])->all(),
        ]);
    }

    /** GET /customer/menu-items?category=<name>&page= */
    public function menuItems(Request $request): AnonymousResourceCollection
    {
        $validated = $request->validate([
            'category' => ['nullable', 'string', 'max:100'],
        ]);

        $category = $validated['category'] ?? null;

        $items = $this->visibleFoods()
            ->when($category !== null && $category !== '', fn (Builder $q) => $q->whereHas(
                'category',
                fn (Builder $c) => $c->where('name', $category)
            ))
            ->orderBy('sort_order')
            ->paginate(20);

        return FoodResource::collection($items);
    }

    /** Only restaurants the admin approved and has not blocked. */
    private function visibleRestaurants(): Builder
    {
        return Restaurant::query()
            ->where('is_active', true)
            ->where('is_approved', true);
    }

    /** Available food that belongs to a visible restaurant. */
    private function visibleFoods(): Builder
    {
        return Food::query()
            ->where('is_available', true)
            ->whereHas('restaurant', fn (Builder $q) => $q->where('is_active', true)->where('is_approved', true))
            ->with('category:id,name,emoji', 'restaurant:id,name,slug');
    }
}
